-- phpMyAdmin SQL Dump
-- version 4.4.1.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 16 2015 г., 00:54
-- Версия сервера: 5.6.21-70.0-1-beget-log
-- Версия PHP: 5.5.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `midnigli_lodki`
--

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--
-- Создание: Апр 11 2015 г., 02:49
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(5) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(8, 'Green'),
(13, 'Grey'),
(3, 'Pink'),
(9, 'Red'),
(11, 'Yellow');

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--
-- Создание: Апр 11 2015 г., 02:49
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`id`, `name`, `phone`, `email`) VALUES
(1, 'Владимир', '+7-921-456-86-95', 'ghost@mail.ru'),
(2, 'Нина Евгеньевна', '456-98-65', 'home@yandex.ru'),
(24, 'Ser', '55-44-33', 'fdre@mail.ru'),
(25, 'Ser', '55-44-33', 'fdre@mail.ru'),
(26, 'Ser', '55-44-33', 'fdre@mail.ru'),
(27, 'Var', '222-666', 'emeil'),
(28, 'Var', '222-666', 'emeil'),
(29, 'Ваше имя', 'Ваш телефон', 'Ваш емейл'),
(30, 'Виктория', '22345565', 'midnight_@bk.ru'),
(31, 'SSS', '111', 'infomail.spb@yandex.ru'),
(32, 'Ваше имя', 'Ваш телефон', 'Ваш емейл'),
(33, 'Ваше имя', 'Ваш телефон', 'Ваш емейл'),
(34, 'Ваше имя', 'Ваш телефон', 'Ваш емейл'),
(35, 'Ваше имя', 'Ваш телефон', 'Ваш емейл'),
(36, 'midnight_@bk.ru', 'Ваш телефон', 'midnight_@bk.ru'),
(37, '', '', ''),
(38, 'bk', '776', '767'),
(39, 'midnight_@bk.ru', '12233345', 'midnight_@bk.ru'),
(40, 'www', '222', 'sss@ss'),
(41, 'wwq', '332', 'wwe@ww'),
(42, 'Сергей', '332211', 'lavrovdoctor@mail.ru'),
(43, 'ff', '44', 'lavrovdoctor@mail.ru'),
(44, 'rr', '66', 'lavrovdoctor@mail.ru'),
(45, 'qqq', '111', 'lavrovdoctor@mail.ru'),
(46, 'ффффффффф', '22222222', 'lavrovdoctor@mail.ru'),
(47, 'кк', '222', 'ee@xn--ee-tnc.xn--o1aa'),
(48, 'fff', '777', 'ddd@xn--l1aahbcd.xn--c1an3d'),
(49, 'йй', '33', 'gcgfcgf@xn--l1aaicbc.xn--b1a7a'),
(50, 'eee', '658', 'cgfcgf@xn--80a3aah.xn--e1ak'),
(51, 'ирои', '54345', 'gdg@xn--80a5ab.xn--o1ab'),
(52, 'hh', '88', 'hh@xn--80aaa.xn--d1aa'),
(53, 'пп', '6543', 'hg@xn--p1aa.xn--k1aa'),
(54, 'jj', '77', 'hgf@xn--b1aa0bi2e.xn--k1ag'),
(55, 'пп', '88', 'jj@xn--80ad1bdg6f.xn--d1ao'),
(56, 'ир', '6665544', 'drcd@xn--80ad4b.xn--k1ag'),
(57, 'gg', '668855', 'dss@xn--80ad8e.xn--d1ao'),
(58, 'nun', '7777', 'gvg@xn--80aa6bicb5g.xn--d1ao'),
(59, 'т', '7', 'vgyv@xn--b1aa6d'),
(60, 'рпа', '654', 'gf_jjnjn.dcj@hgыg.hh'),
(61, 'gg', '757', 'jgfcgf@xn--n1aaacbdcc.xn--o1ab'),
(62, 'Сер', '7654345', '555@xn--n1acc.hg'),
(63, 'CSer', '7654653', 'utt5@xn--80a3ac2d.hg'),
(64, 'fhhu', '7', 'hggf@hvhvhg.jh'),
(65, 'в', '4', '4@q.wq'),
(66, 'h edb', '8658658', 'jbjhb@d.kj'),
(67, 'аеан', '75756565', 'ccdc@ggvh.kj'),
(68, 'hvgvh', '777', 'jbbg@fxfxd.hg');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--
-- Создание: Апр 11 2015 г., 02:49
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL,
  `date` varchar(30) NOT NULL,
  `client_id` int(11) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `date`, `client_id`) VALUES
(1, '2015-03-18', 1),
(2, '2015-03-17', 2),
(3, '0000-00-00', 4),
(4, '0000-00-00', 5),
(5, '0000-00-00', 6),
(6, '0000-00-00', 7),
(7, '0000-00-00', 8),
(8, '0000-00-00', 9),
(9, '0000-00-00', 10),
(10, '0000-00-00', 11),
(11, '0000-00-00', 12),
(12, '0000-00-00', 0),
(13, '0000-00-00', 0),
(14, '0000-00-00', 0),
(15, '0000-00-00', 0),
(16, '0000-00-00', 0),
(17, '0000-00-00', 21),
(18, '0000-00-00', 22),
(20, '0000-00-00', 24),
(21, '0000-00-00', 25),
(22, '0000-00-00', 26),
(23, '0000-00-00', 27),
(24, '0000-00-00', 28),
(25, '0000-00-00', 29),
(26, '0000-00-00', 30),
(27, '0000-00-00', 31),
(28, '0000-00-00', 32),
(29, '0000-00-00', 33),
(30, '19/03/2015 23:40:50', 34),
(31, '19/03/2015 23:41:48', 35),
(32, '22/03/2015 00:44:51', 36),
(33, '22/03/2015 01:33:38', 37),
(34, '22/03/2015 01:39:40', 38),
(35, '22/03/2015 09:51:48', 39),
(36, '23/03/2015 19:53:48', 40),
(37, '23/03/2015 19:57:32', 41),
(38, '23/03/2015 21:19:04', 42),
(39, '23/03/2015 21:22:26', 43),
(40, '23/03/2015 21:23:26', 44),
(41, '23/03/2015 21:31:17', 45),
(42, '23/03/2015 21:40:51', 46),
(43, '27/03/2015 09:53:19', 47),
(44, '27/03/2015 10:04:34', 48),
(45, '27/03/2015 10:06:30', 49),
(46, '27/03/2015 11:10:01', 50),
(47, '27/03/2015 11:10:48', 51),
(48, '27/03/2015 14:15:12', 52),
(49, '27/03/2015 14:17:09', 53),
(50, '27/03/2015 14:28:35', 54),
(51, '27/03/2015 15:01:35', 55),
(52, '27/03/2015 15:03:02', 56),
(53, '27/03/2015 15:06:26', 57),
(54, '27/03/2015 15:17:04', 58),
(55, '27/03/2015 15:20:41', 59),
(56, '28/03/2015 16:23:42', 60),
(57, '14/04/2015 13:53:25', 61),
(58, '15/04/2015 23:41:09', 62),
(59, '15/04/2015 23:45:11', 63),
(60, '15/04/2015 23:49:03', 64),
(61, '15/04/2015 23:58:01', 65),
(62, '16/04/2015 00:05:09', 66),
(63, '16/04/2015 00:44:16', 67),
(64, '16/04/2015 00:48:47', 68);

-- --------------------------------------------------------

--
-- Структура таблицы `order_prod`
--
-- Создание: Апр 11 2015 г., 02:49
--

DROP TABLE IF EXISTS `order_prod`;
CREATE TABLE IF NOT EXISTS `order_prod` (
  `order_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `amount` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_prod`
--

INSERT INTO `order_prod` (`order_id`, `prod_id`, `amount`) VALUES
(1, 3, 3),
(1, 113, 2),
(20, 7, 2),
(20, 1, 1),
(21, 7, 2),
(21, 1, 1),
(22, 7, 2),
(22, 1, 1),
(23, 7, 2),
(23, 1, 1),
(24, 7, 2),
(24, 1, 1),
(25, 7, 2),
(26, 3, 4),
(26, 7, 3),
(26, 8, 6),
(27, 3, 2),
(27, 4, 3),
(28, 3, 2),
(29, 3, 2),
(30, 4, 1),
(32, 3, 3),
(32, 4, 80),
(33, 3, 109),
(34, 8, 3),
(35, 7, 6),
(35, 4, 1),
(35, 12, 3),
(36, 8, 3),
(37, 3, 1),
(38, 1, 2),
(39, 1, 1),
(40, 1, 2),
(41, 1, 1),
(42, 3, 3),
(43, 1, 1),
(43, 138, 4),
(44, 1, 2),
(45, 3, 1),
(46, 4, 2),
(47, 3, 2),
(48, 3, 1),
(49, 1, 1),
(50, 4, 1),
(51, 3, 1),
(52, 4, 1),
(53, 1, 1),
(54, 1, 1),
(55, 3, 1),
(56, 3, 1),
(57, 4, 1),
(57, 3, 1),
(58, 3, 2),
(58, 4, 2),
(59, 3, 2),
(59, 4, 2),
(60, 3, 2),
(60, 4, 2),
(61, 141, 9),
(62, 141, 100),
(63, 4, 123),
(63, 8, 231),
(63, 3, 1231),
(63, 150, 1),
(64, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--
-- Создание: Апр 15 2015 г., 09:44
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `price`, `img`) VALUES
(1, 'name1', 'effe', '555.00', NULL),
(3, 'name421', 'bfjhkn', '5454.45', 'piglet'),
(4, 'name4', 'kabef', '8833.00', 'guffy'),
(5, 'dream', 'big and fast', '444.98', NULL),
(7, 'dream2', 'big and fast', '444.98', NULL),
(8, 'dream3', 'bgg hh', '555.00', NULL),
(10, 'newidea', 'lh;ohuh', '56.90', NULL),
(12, 'newidea2', 'lh;ohuh 555', '56.90', NULL),
(109, 'aa', 'jjj', '9.00', NULL),
(111, 'cc', 'jjj', '9.00', NULL),
(112, 'ccv', 'jjj', '9.00', NULL),
(113, 'ccvb', 'jjj', '9.00', NULL),
(114, 'xxxx', 'jjj', '9.00', NULL),
(115, 'mmm', 'jjj', '9.00', NULL),
(116, 'mmmb', 'jjj', '9.00', NULL),
(117, 'mmmbq', 'jjj', '9.00', NULL),
(118, 'vvc', 'jjj', '9.00', NULL),
(119, 'ggg', 'jjj', '9.00', NULL),
(120, 'koir', 'jjj', '9.00', NULL),
(122, 'utf8', 'jjj', '9.00', NULL),
(123, 'gghh', '', '0.00', NULL),
(124, 'gghhaa', '', '0.00', NULL),
(125, 'zz', '', '0.00', NULL),
(126, 'zzh', 'n', '0.00', NULL),
(127, 'New ship', '.kllvk iftftfk khctyc ', '869.00', NULL),
(129, 'New ship2', '.kllvk iftftfk khctyc hc rc jcjr', '976.00', NULL),
(131, 'New ship3', '.kllvk iftftfk khctyc hc rc jcjr', '976.00', NULL),
(135, 'read3', ' fbtbfu buhftbufh', '543.00', NULL),
(138, 'thi is new', 'kblhbl', '786.00', NULL),
(139, 'Новый товар', 'Описание', '765.00', NULL),
(140, 'Вася', 'вася', '33.00', NULL),
(141, 'eew', 'ededed', '43243.00', NULL),
(142, 'eewf', 'kfff', '852.00', NULL),
(143, 'good4', 'hbljvkjvjv', '783.00', NULL),
(150, 'тртг', 'шии', '97.00', NULL),
(151, 'a', '', '0.00', NULL),
(154, 'k', 'gg', '555.00', NULL),
(156, '33', '33', '0.00', NULL),
(157, 'a1', 'igvfctc ivuyvy', '66.87', NULL),
(158, 'f3', 'mnbv', '759.98', NULL),
(159, 'f', 'gg', '9865.00', NULL),
(160, 'ggf', 'Описание товара&lt;br /&gt;содержи несколько&lt;br /&gt;строк текста', '554.00', NULL),
(161, 'ss', 'Описание товара<br />содержит несколько<br />строк текста', '43.40', NULL),
(162, 'jjk', 'k;jbnj', '76576.80', NULL),
(163, 'dsae', 'on', '87.00', NULL),
(164, 'eewh', 'knnk', '97.00', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `prod_categ_link`
--
-- Создание: Апр 11 2015 г., 02:49
--

DROP TABLE IF EXISTS `prod_categ_link`;
CREATE TABLE IF NOT EXISTS `prod_categ_link` (
  `id_prod` int(11) NOT NULL,
  `id_cat` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `prod_categ_link`
--

INSERT INTO `prod_categ_link` (`id_prod`, `id_cat`) VALUES
(162, NULL),
(3, 3),
(4, 3),
(135, 3),
(150, 3),
(161, 3),
(8, 8),
(12, 8),
(131, 8),
(154, 8),
(159, 8),
(142, 9),
(163, 9),
(127, 11),
(164, 11),
(141, 13),
(143, 13);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Апр 11 2015 г., 02:49
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL,
  `user_login` varchar(30) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  `user_hash` varchar(32) NOT NULL,
  `user_ip` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `user_login`, `user_password`, `user_hash`, `user_ip`) VALUES
(1, 'admin', 'password', 'kjvubytcuvi', 0),
(2, 'qwerty', '897c8fde25c5cc5270cda61425eed3c8', '28343b9db5de5325bde54962ff5b8011', 1578328683),
(3, '12345', '1f32aa4c9a1d2ea010adcf2348166a04', '19284eccc26cb2659f571c6e276de0bf', 1578328683),
(4, 'zxcvb', '3a607ab88470be4983f1ee7b75cb4d9e', '', 0),
(5, 'qqqqq', 'cea0c35b93258dd8ac9242dc48b15405', '', 0),
(6, 'wwwww', '080416d0fdca8d64c453f63a681bce72', '3dfbb65023ab722171ce85485902065e', 1578328683),
(7, '23456', '1eb04185280560d6e6a70eae59459558', '6ba2f96c798bd4bbc17547f953763def', 1578328683),
(8, '34567', '984e0037bc680040c3165a33fc64e091', '', 0),
(9, '45678', 'ddf2cc7664087315c1a86476710ff53e', '', 0),
(10, '56789', '8d7f16e975fc1a3c9e1b845830847452', '', 0),
(11, '67890', 'd3b1f6609750d8dee770764f4b3f2a18', '', 0),
(12, '11111', '3cdf5666859f6906c283a1058cd5b9a7', 'e62b7b8b50f88b777acbe306c1bec7a2', 1578328683),
(13, 'asdfg', 'f63acfe4794aefd8111c8b922f48406e', '80a8eac0172bd8e02f483e94b9c6695c', 1578328683),
(14, 'qazwsx', 'ef4ddf645aa223c0b2b1356fbb4fd90a', '886b17aa97304e78888ce5059444b737', 1578328683),
(15, '22222', '38026ed22fc1a91d92b5d2ef93540f20', '', 0),
(16, '77777', '31bee2e05d448b7145b8d837fecd5b76', '628e0882127cf32e5bf80a8f1998ecce', 1578328683);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category` (`category`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `id` (`id`);

--
-- Индексы таблицы `order_prod`
--
ALTER TABLE `order_prod`
  ADD KEY `order_id` (`order_id`),
  ADD KEY `prod_id` (`prod_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Индексы таблицы `prod_categ_link`
--
ALTER TABLE `prod_categ_link`
  ADD UNIQUE KEY `id_prod_2` (`id_prod`),
  ADD KEY `id_prod` (`id_prod`),
  ADD KEY `id_cat` (`id_cat`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=167;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `order_prod`
--
ALTER TABLE `order_prod`
  ADD CONSTRAINT `order_prod_ibfk_1` FOREIGN KEY (`prod_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_prod_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `prod_categ_link`
--
ALTER TABLE `prod_categ_link`
  ADD CONSTRAINT `prod_categ_link_ibfk_1` FOREIGN KEY (`id_prod`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prod_categ_link_ibfk_2` FOREIGN KEY (`id_cat`) REFERENCES `category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
